<div class="left-context">
    <div class="lc-top">
        <div class="lc-head">
            <img src="/img/ouakademi-logo.svg" alt="">
            <h2>Oyun ve Uygulama Akademisi</h2>
        </div>
        <div class="lc-context">
            <h1>Soru Sor</h1>
            <h5>Soru oluşturabilir, cevaplayabilir ve sorularınızı düzenleyebilirsiniz.</h5>
        </div>
    </div>
    <div class="lc-bottom">
        <a href="https://join.slack.com/t/oyunveuygulama/shared_invite/zt-zv9d1lsn-njscscSjYoD~fk_hA84PHA" target="_blank">Slack kanalına git</a>
        <a href="https://oyunveuygulamaakademisi.com/egitimler" target="_blank">Eğitimlere git</a>
    </div>
</div>
