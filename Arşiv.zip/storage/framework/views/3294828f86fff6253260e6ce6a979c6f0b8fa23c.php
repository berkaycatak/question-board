<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
        <div class="main-header">
            <h5>✍🏻 SORU TAHTASI</h5>

            <h1><?php echo e($event->name); ?></h1>

            <div class="main-header-specs">
                <div class="mhs-item" style="display: flex;">
                    <img class="ecs-item" height="25" width="25" style="border-radius: 50%;" src="<?php echo e($event->user_profile_photo_path == null ? 'https://ui-avatars.com/api/?name='. $event->user_name : '/storage/'.$event->user_profile_photo_path); ?>" alt="<?php echo e($event->user_name); ?>">
                    <span class="ecs-item-text" style="margin-left: 5px;"><?php echo e($event->user_name); ?></span>
                </div>
                <div class="mhs-item">
                    <span>⏰</span>
                    <span class="ecs-item-text"><?php echo e($event->time); ?></span>
                </div>
                <div class="mhs-item">
                    <span>🗓</span>
                    <span class="ecs-item-text"><?php echo e($event->date); ?></span>
                </div>
                <div class="mhs-item">
                    <div class="ecs-item">
                        <a target="_blank" href="<?php echo e($event->adress); ?>">Etkinliğe git</a>
                    </div>
                </div>
                <?php if(isset(Auth::user()->id)): ?>
                    <?php if($event->created_user_id == Auth::user()->id): ?>
                        <div class="mhs-item">
                            <div class="ecs-item">
                                <a href="<?php echo e(route('event.edit', $event->id)); ?>">Etkinliği düzenle</a>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
            <p class="event-description"><?php echo e($event->description); ?></p>

            <hr>
        </div>

            <?php if(isset($get_question)): ?>
                <form class="mcr-content add-question-form" method="POST" action="<?php echo e(route('question_update', [$event->id, $get_question->id])); ?>">
                    <?php echo csrf_field(); ?>
                    <label for="addquestion">💬 Soruyu düzenle</label>
                    <textarea required name="question" id="addquestion" rows="1"><?php echo e($get_question->question); ?></textarea>

                    <div class="checkbox">
                        <input id="anonim" name="anonim" type="checkbox" <?php if($get_question->is_anonim == 1): ?> checked <?php endif; ?>>
                        <label for="anonim">İsmim görünmesin</label>
                    </div>

                    <input type="submit" value="Kaydet">
                </form>
            <?php else: ?>
                <form class="mcr-content add-question-form" method="POST" action="<?php echo e(route('question_store', $event->id)); ?>">
                    <?php echo csrf_field(); ?>
                    <label for="addquestion">💬 Soru Ekle</label>
                    <textarea required name="question" id="addquestion" rows="1"></textarea>

                    <?php if(isset(Auth::user()->id)): ?>
                        <div class="checkbox">
                            <input id="anonim" name="anonim" type="checkbox">
                            <label for="anonim">İsmim görünmesin</label>
                        </div>
                    <?php else: ?>
                        <a href="<?php echo e(route('register')); ?>" style="color: black; margin-top: 10px;">Kayıt olarak isimli sor.</a>
                    <?php endif; ?>
                    <input type="submit" value="Gönder">
                </form>
            <?php endif; ?>
            <label class="questions-title">🤔 Sorular</label>
            <div class="main-content">
                <div class="questions">
                    <?php if(count($questions) > 0): ?>
                        <?php ($counter = 0); ?>
                        <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="mc-item <?php if($question->is_answered): ?> is-answered <?php endif; ?> ">
                                <div class="mci-head">
                                    <span><?php echo e($question->is_answered ? '✅' : '💬'); ?> &nbsp;</span>
                                    <?php if($question->created_user_id != null && $question->is_anonim == 0): ?>
                                        <?php ($sender_name = DB::table('users')->where('id', $question->created_user_id)->select('name')->first()->name); ?>
                                    <?php else: ?>
                                        <?php ($sender_name = "anonim"); ?>
                                    <?php endif; ?>
                                    <span <?php if($question->is_answered): ?> class="is-answered-text" <?php endif; ?>> <?php echo e(timeConvert($question->created_at)); ?> <?php echo e($sender_name); ?> tarafından gönderildi.</span>
                                </div>
                                <div class="mci-context">
                                    <span  <?php if($question->is_answered): ?> class="color-white" <?php endif; ?> ><?php echo e($question->question); ?></span>
                                    <?php if(isset(Auth::user()->id)): ?>
                                        <?php if(Auth::user()->id == $event->created_user_id): ?>

                                            <small <?php if($question->is_answered): ?> class="color-white-ac" <?php endif; ?> >
                                                <a href="<?php echo e(route("question_answered", ["event_id" => $event->id, "question_id" => $question->id])); ?>">Cevaplandı</a> | <a href="<?php echo e(route("question_delete", ["event_id" => $event->id, "question_id" => $question->id])); ?>">Sil</a>
                                            </small>
                                        <?php endif; ?>
                                        <?php if(Auth::user()->id == $question->created_user_id): ?>
                                            <small <?php if($question->is_answered): ?> class="color-white-ac" <?php endif; ?> >
                                                <a href="<?php echo e(route("question_edit", ["event_id" => $event->id, "question_id" => $question->id])); ?>">Düzenle</a> | <a href="<?php echo e(route("question_delete", ["event_id" => $event->id, "question_id" => $question->id])); ?>">Sil</a>
                                            </small>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <?php ($counter++); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <span class="no-question">
                            Herhangi bir soru bulunamadı. İlk sen sor!
                        </span>
                    <?php endif; ?>
                </div>
            </div>
     </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH /Users/berkaycatak/Desktop/laravel/soru/resources/views/pages/events/single.blade.php ENDPATH**/ ?>