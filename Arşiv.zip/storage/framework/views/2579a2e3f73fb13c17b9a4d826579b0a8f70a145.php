<?php echo e($slot); ?>

<?php /**PATH /Users/berkaycatak/Desktop/laravel/soru/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>