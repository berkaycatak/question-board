<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="main-header">
        <h5 class="main-header-h5">✍🏻 ETKİNLİK PANOSU</h5>
        <h1>Etkinliği düzenle</h1>
        <a class="main-header-a" href="<?php echo e(route('dashboard')); ?>">Etkinliklerime git</a>
    </div>
    <div class="main-context">
        <h2 class="mc-h2-event">Etkinliği düzenle</h2>
        <form method="POST" action="<?php echo e(route('event.update', $event->id)); ?>" class="main-content-form">
            <?php echo method_field('put'); ?>
            <?php echo csrf_field(); ?>
            <label for="eventname">Adı *</label>
            <input class="mb" name="name" <?php if(old('name') != ""): ?> value="<?php echo e(old('name')); ?>" <?php else: ?> value="<?php echo e($event->name); ?>" <?php endif; ?>  type="text" placeholder="Etkinliğin adını girin" required>
            <label for="eventtime">⏰ Saati *</label>
            <input class="mb" name="time" <?php if(old('time') != ""): ?> value="<?php echo e(old('time')); ?>" <?php else: ?> value="<?php echo e($event->time); ?>" <?php endif; ?> type="text" placeholder="Etkinliğin saatini girin Örn: 13:00" required>
            <label for="eventtime">👀 Konusu</label>
            <input class="mb" name="description" <?php if(old('description') != ""): ?> value="<?php echo e(old('description')); ?>" <?php else: ?> value="<?php echo e($event->description); ?>" <?php endif; ?> type="text" placeholder="Etkinliğin konusunu girin">
            <label for="eventtime">📍 Adresi</label>
            <input class="mb" name="adress" <?php if(old('adress') != ""): ?> value="<?php echo e(old('adress')); ?>" <?php else: ?> value="<?php echo e($event->adress); ?>" <?php endif; ?>  type="text" placeholder="Etkinliğin adresini girin">
            <label for="eventdate">🗓 Günü *</label>
            <input class="mb" name="date" <?php if(old('date') != ""): ?> value="<?php echo e(old('date')); ?>" <?php else: ?> value="<?php echo e($event->date); ?>" <?php endif; ?> type="date" placeholder="Etkinliğin gününü GG.AA.YYYY şeklinde girin" required>
            <input type="submit" value="Düzenle">
        </form>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH /Users/berkaycatak/Desktop/laravel/soru/resources/views/pages/events/edit.blade.php ENDPATH**/ ?>