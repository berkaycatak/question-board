<div class="nav">
    <input type="checkbox" id="nav-check">
    <div class="nav-header">
        <div class="nav-title"  onclick="window.location = '/'">
            <img class="h-brand-img" src="/img/ouakademi-logo-colored.svg" alt="">
            <h3>Soru Tahtası</h3>
        </div>
    </div>
    <div class="nav-btn">
        <label for="nav-check">
            <span></span>
            <span></span>
            <span></span>
        </label>
    </div>

    <div class="nav-links ">
        <a href="<?php echo e(route('event.index')); ?>">Etkinlikler</a>

        <?php if(isset(Auth::user()->id)): ?>
            <a href="<?php echo e(route('event.create')); ?>">Etkinlik oluştur</a>

                <li class="button-dropdown">
                    <a href="javascript:void(0)" class="dropdown-toggle">
                        <?php echo e(Auth::user()->name); ?> <span>▼</span>
                    </a>
                    <ul class="dropdown-menu" style="display: none">
                        <li><a href="<?php echo e(route('profile.show')); ?>">Profilim</a></li>
                        <li><a href="<?php echo e(route('dashboard')); ?>">Panelim</a></li>
                        <li>
                            <form action="<?php echo e(route('logout')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <li><button type="submit">Çıkış Yap</button></li>
                            </form>

                        </li>
                    </ul>
                </li>

            <?php if(false): ?>
                <div class="fink">
                    <details>
                        <summary><?php echo e(Auth::user()->name); ?></summary>
                        <li><a href="<?php echo e(route('profile.show')); ?>">Profilim</a></li>
                        <li><a href="<?php echo e(route('dashboard')); ?>">Panelim</a></li>
                        <form action="<?php echo e(route('logout')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <li><button type="submit">Çıkış Yap</button></li>
                        </form>
                    </details>
                </div>
            <?php endif; ?>




        <?php else: ?>
            <a href="<?php echo e(route('login')); ?>">Giriş Yap</a>
            <a href="<?php echo e(route('register')); ?>">Kayıt Ol</a>
        <?php endif; ?>
    </div>
</div>


<?php /**PATH /Users/berkaycatak/Desktop/laravel/soru/resources/views/layouts/components/header.blade.php ENDPATH**/ ?>