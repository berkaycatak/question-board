<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="main-header">
        <h5>👀 Panelim</h5>
        <h1>Etkinliklerim</h1>
    </div>

    <div class="main-events">
        <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="event-card">
                <a href="<?php echo e(route('event.show', $event->id)); ?>"><h3><?php echo e($event->name); ?></h3></a>
                <div class="event-card-spec">
                    <div class="ecs-item">
                        <span>⏰</span>
                        <span class="ecs-item-text"> <?php echo e($event->time); ?></span>
                    </div>
                    <div class="ecs-item">
                        <span>🗓</span>
                        <span class="ecs-item-text"><?php echo e($event->date); ?></span>
                    </div>
                    <div class="ecs-item">
                        <a href="<?php echo e(route('event.edit', $event->id)); ?>">Etkinliği düzenle</a>
                    </div>
                    <div class="ecs-item">
                        <a href="<?php echo e(route('event.show', $event->id)); ?>">Etkinliğe git</a>
                    </div>
                    <div class="ecs-item">
                        <form method="POST" action="<?php echo e(route('event.destroy', $event->id)); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button onclick="return confirm('Silmek istediğinizden emin misiniz ?')" class="danger-button" type="submit">Etkinliği sil</button>
                        </form>
                    </div>

                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($events->links()); ?>

    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH /Users/berkaycatak/Desktop/laravel/soru/resources/views/dashboard.blade.php ENDPATH**/ ?>