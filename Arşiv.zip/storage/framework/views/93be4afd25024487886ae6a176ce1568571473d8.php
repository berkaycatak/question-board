<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="landing-page">
        <h1>Soru Tahtası</h1>
        <h3>Linkini paylaş ve soruları gör!</h3>
        <p>Soru Tahtası kullanarak etkinlik oluştur, linkini paylaş, ister anonim ister isim soyisim ile soruları kabul et!</p>
        <div class="landing-buttons">
            <?php if(isset(Auth::user()->id)): ?>
                <a href="<?php echo e(route("event.create")); ?>"><button class="green-button">Etkinlik oluştur</button></a>
            <?php else: ?>
                <a href="<?php echo e(route("login")); ?>"><button class="green-button">Giriş yap</button></a>
                <a href="<?php echo e(route("register")); ?>"><button class="blue-button">Kayıt ol</button></a>
            <?php endif; ?>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH /Users/berkaycatak/Desktop/laravel/soru/resources/views/welcome.blade.php ENDPATH**/ ?>