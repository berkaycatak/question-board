<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="main-header">
        <h5 class="main-header-h5">✍🏻 ETKİNLİK PANOSU</h5>
        <h1>Etkinlik Oluştur</h1>
        <a class="main-header-a" href="<?php echo e(route('event.index')); ?>">Etkinlik listesine git</a>
    </div>
    <div class="main-context">
        <h2 class="mc-h2-event">Etkinlik Ekle</h2>
        <form method="POST" action="<?php echo e(route('event.store')); ?>" class="main-content-form">
            <?php echo csrf_field(); ?>
            <label for="eventname">Adı *</label>
            <input class="mb" name="name" value="<?php echo e(old('name')); ?>" type="text" placeholder="Etkinliğin adını girin" required>
            <label for="eventtime">⏰ Saati *</label>
            <input class="mb" name="time" value="<?php echo e(old('time')); ?>" type="text" placeholder="Etkinliğin saatini girin Örn: 13:00" required>
            <label for="eventtime">👀 Konusu</label>
            <input class="mb" name="description" value="<?php echo e(old('description')); ?>" type="text" placeholder="Etkinliğin konusunu girin">
            <label for="eventtime">📍 Adresi</label>
            <input class="mb" name="adress" value="<?php echo e(old('adress')); ?>" type="text" placeholder="Etkinliğin adresini girin">
            <label for="eventdate">🗓 Günü *</label>
            <input class="mb" name="date" value="<?php echo e(old('date')); ?>" type="date" placeholder="Etkinliğin gününü GG.AA.YYYY şeklinde girin" required>
            <input type="submit" value="Ekle">
        </form>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH /Users/berkaycatak/Desktop/laravel/soru/resources/views/pages/events/create.blade.php ENDPATH**/ ?>