<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo e(config('app.name', 'Laravel')); ?></title>

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap">

        <!-- Styles -->
        <link rel="stylesheet" href="/css/style.css">
        <link rel="stylesheet" href="/css/app.css">
        <link rel="stylesheet" href="/css/events.css">

        <?php echo \Livewire\Livewire::styles(); ?>


        <!-- Scripts -->
        <script src="<?php echo e(mix('js/app.js')); ?>" defer></script>
    </head>
    <body>
        <?php echo $__env->make('layouts.components.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <main>
            <?php if(isset($errors)): ?>
                <?php if($errors->any()): ?>
                    <div class="container mt-3">
                        <div class="mt-3 form-error-top">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li> <?php echo e($error); ?> </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                <?php endif; ?>
            <?php endif; ?>

            <?php if(session('success') != ""): ?>
                <div class="container mt-3">
                    <?php (printSuccessMessage(session('success'))); ?>
                </div>
            <?php endif; ?>

            <?php if(session('error') != ""): ?>
                <div class="container mt-3">
                    <?php (printErrorMessage(session('error'))); ?>
                </div>
            <?php endif; ?>

            <?php echo e($slot); ?>


            <footer>
                <a target="_blank" href="https://www.medialyra.com/">
                    <img height="30" src="https://medialyra.com/wp-content/uploads/2021/11/lyra.png" alt="Media Lyra">
                </a>
                <span>| Copyright © <?php echo e(date('Y')); ?> Tüm Hakları Saklıdır.</span>
            </footer>
        </main>

        <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
        <script src="/js/custom.js"></script>
    </body>
    <?php echo $__env->yieldPushContent('modals'); ?>

    <?php echo \Livewire\Livewire::scripts(); ?>


</html>
<?php /**PATH /Users/berkaycatak/Desktop/laravel/soru/resources/views/layouts/app.blade.php ENDPATH**/ ?>