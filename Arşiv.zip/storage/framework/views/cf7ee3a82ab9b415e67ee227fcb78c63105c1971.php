<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <main>
        <div class="main-header">
            <h5>👀 Etkinlikler</h5>
            <h1>Yaklaşan Etkinlikler</h1>
        </div>
        <div class="main-events">
            <div class="event-card">
                <a href="eventdetail.html"><h3>Donut Etkinliği: SpatialChat #2</h3></a>
                <div class="event-card-spec">
                    <div class="ecs-item">
                        <span>⏰</span>
                        <span class="ecs-item-text">15:00</span>
                    </div>
                    <div class="ecs-item">
                        <span>🗓</span>
                        <span class="ecs-item-text">14 Ocak 2022</span>
                    </div>
                    <div class="ecs-item">
                        <a href="eventdetail.html">Soru sor</a>
                    </div>
                    <div class="ecs-item">
                        <a href="<?php echo e(route('event.show', 1)); ?>">Etkinliğe git</a>
                    </div>
                </div>
            </div>
            <div class="event-card">
                <a href="eventdetail.html"><h3>Donut Etkinliği: SpatialChat #2</h3></a>
                <div class="event-card-spec">
                    <div class="ecs-item">
                        <span>⏰</span>
                        <span class="ecs-item-text">15:00</span>
                    </div>
                    <div class="ecs-item">
                        <span>🗓</span>
                        <span class="ecs-item-text">14 Ocak 2022</span>
                    </div>
                    <div class="ecs-item">
                        <a href="eventdetail.html">Soru sor</a>
                    </div>
                    <div class="ecs-item">
                        <a href="<?php echo e(route('event.show', 1)); ?>">Etkinliğe git</a>
                    </div>
                </div>
            </div>
            <div class="event-card">
                <a href="eventdetail.html"><h3>Donut Etkinliği: SpatialChat #2</h3></a>
                <div class="event-card-spec">
                    <div class="ecs-item">
                        <span>⏰</span>
                        <span class="ecs-item-text">15:00</span>
                    </div>
                    <div class="ecs-item">
                        <span>🗓</span>
                        <span class="ecs-item-text">14 Ocak 2022</span>
                    </div>
                    <div class="ecs-item">
                        <a href="eventdetail.html">Soru sor</a>
                    </div>
                    <div class="ecs-item">
                        <a href="<?php echo e(route('event.show', 1)); ?>">Etkinliğe git</a>
                    </div>
                </div>
            </div>
        </div>
    </main>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH /Users/berkaycatak/Desktop/laravel/soru/resources/views/pages/events.blade.php ENDPATH**/ ?>